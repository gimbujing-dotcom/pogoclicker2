package com.example.pogoclicker

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }

        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_star)
        }, LinearLayout.LayoutParams(dp(160), dp(160)))

        root.addView(TextView(this).apply {
            text = "포켓몬고 클리커"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(24))
        })

        root.addView(TextView(this).apply { text = "클릭 간격 (ms, 최소 60)" })
        input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(prefs.getLong("interval", 100L).toString())
        }
        root.addView(input, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener {
                save()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        root.addView(TextView(this).apply {
            text = "1. 위 버튼 → 설치된 앱 → 포켓몬고 클리커 → 켜기\n" +
                "2. 화면에 별(시작/정지)과 빨간 조준점이 떠요\n" +
                "3. 조준점을 누르고 싶은 곳으로 드래그\n" +
                "4. 별을 탭하면 시작, 다시 탭하면 정지\n" +
                "(별과 조준점은 드래그로 옮길 수 있어요)"
            setPadding(0, dp(16), 0, 0)
            setLineSpacing(0f, 1.2f)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun save() {
        val v = input.text.toString().toLongOrNull() ?: 100L
        getSharedPreferences("prefs", MODE_PRIVATE).edit()
            .putLong("interval", v.coerceAtLeast(60L)).apply()
    }

    override fun onPause() {
        save()
        super.onPause()
    }
}
