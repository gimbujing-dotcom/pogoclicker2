package com.example.pogoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageView
import android.widget.Toast
import kotlin.math.abs

class ClickService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var fab: ImageView
    private lateinit var target: ImageView
    private lateinit var fabLp: WindowManager.LayoutParams
    private lateinit var targetLp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            clickTarget()
            handler.postDelayed(this, interval())
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun interval(): Long =
        getSharedPreferences("prefs", MODE_PRIVATE).getLong("interval", 100L).coerceAtLeast(60L)

    private fun params(size: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        size, size,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x
        this.y = y
    }

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics

        // 클릭 위치를 정하는 빨간 조준점 (드래그로 이동)
        target = ImageView(this).apply { setImageResource(R.drawable.ic_target) }
        targetLp = params(dp(64), dm.widthPixels / 2 - dp(32), dm.heightPixels / 2 - dp(32))
        wm.addView(target, targetLp)
        attachDrag(target, targetLp, null)

        // 시작/정지 버튼 (탭 = 토글, 드래그 = 이동)
        fab = ImageView(this).apply { setImageResource(R.drawable.ic_star) }
        fabLp = params(dp(64), dp(12), dm.heightPixels / 3)
        wm.addView(fab, fabLp)
        attachDrag(fab, fabLp) { setRunning(!running) }
    }

    private fun attachDrag(view: View, p: WindowManager.LayoutParams, onTap: (() -> Unit)?) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        p.x = ox + dx.toInt()
                        p.y = oy + dy.toInt()
                        wm.updateViewLayout(view, p)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap?.invoke()
            }
            true
        }
    }

    private fun setRunning(on: Boolean) {
        running = on
        // 실행 중에는 조준점이 터치를 가로채지 않도록 통과시킴
        targetLp.flags = if (on) targetLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        else targetLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        wm.updateViewLayout(target, targetLp)
        target.alpha = if (on) 0.35f else 1f
        fab.alpha = if (on) 0.6f else 1f
        handler.removeCallbacks(tick)
        if (on) handler.post(tick)
        Toast.makeText(this, if (on) "시작" else "정지", Toast.LENGTH_SHORT).show()
    }

    private fun clickTarget() {
        val loc = IntArray(2)
        target.getLocationOnScreen(loc)
        val path = Path().apply {
            moveTo(loc[0] + target.width / 2f, loc[1] + target.height / 2f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 40))
            .build()
        dispatchGesture(gesture, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        if (::target.isInitialized) setRunning(false)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        running = false
        try { wm.removeView(fab); wm.removeView(target) } catch (_: Exception) {}
        super.onDestroy()
    }
}
